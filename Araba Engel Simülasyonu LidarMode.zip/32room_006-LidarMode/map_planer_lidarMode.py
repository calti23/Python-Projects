import os
import matplotlib
matplotlib.use('TkAgg') 
import matplotlib.pyplot as plt

# Gece Teması (Dark Mode)
plt.style.use('dark_background')

import numpy as np
from scipy.ndimage import distance_transform_edt
import heapq

# --- ROS2 / NAV2 STANDART MALİYET SABİTLERİ ---
COST_FREE = 0
COST_INSCRIBED = 253      # Robotun gövde güvenlik sınırı
COST_LETHAL = 254         # Fiziksel engel merkezi
COST_NO_INFORMATION = 255 # Bilinmeyen alan

# ==============================================================================
# ÇOK KATMANLI HARİTALAMA (MULTI-LAYER COSTMAP) MİMARİSİ
# ==============================================================================

class CostmapLayer:
    def __init__(self, height, width):
        self.height = height
        self.width = width
        self.enabled = True

class StaticLayer(CostmapLayer):
    def __init__(self, grid_map):
        super().__init__(grid_map.shape[0], grid_map.shape[1])
        self.costmap = np.zeros((self.height, self.width), dtype=np.uint8)
        self.costmap[grid_map == 1] = COST_LETHAL

class ObstacleLayer(CostmapLayer):
    def __init__(self, height, width, obstacle_radius=1.1, decay_rate=0.85):
        super().__init__(height, width)
        self.obstacle_radius = obstacle_radius
        self.decay_rate = decay_rate

    def stamp_obstacle(self, master_grid, obs_pos, inflation_radius=1.8, decay_factor=1.2):
        ox, oy = float(obs_pos[0]), float(obs_pos[1])
        r_total = self.obstacle_radius + inflation_radius
        
        min_x = max(0, int(ox - r_total - 1))
        max_x = min(self.width, int(ox + r_total + 2))
        min_y = max(0, int(oy - r_total - 1))
        max_y = min(self.height, int(oy + r_total + 2))
        
        ys, xs = np.ogrid[min_y:max_y, min_x:max_x]
        dists = np.hypot(xs - ox, ys - oy)
        
        lethal_mask = dists <= self.obstacle_radius
        inflated_mask = (dists > self.obstacle_radius) & (dists <= r_total)
        d_inf = dists[inflated_mask] - self.obstacle_radius
        costs_inf = COST_INSCRIBED * np.exp(-decay_factor * d_inf)
        
        sub = master_grid[min_y:max_y, min_x:max_x]
        sub[lethal_mask] = np.maximum(sub[lethal_mask], COST_LETHAL)
        sub[inflated_mask] = np.maximum(sub[inflated_mask], np.clip(costs_inf, 1, COST_INSCRIBED).astype(np.uint8))
        master_grid[min_y:max_y, min_x:max_x] = sub

class InflationLayer(CostmapLayer):
    def __init__(self, height, width, inscribed_radius=0.65, inflation_radius=2.5, decay_factor=0.9):
        super().__init__(height, width)
        self.inscribed_radius = inscribed_radius
        self.inflation_radius = inflation_radius
        self.decay_factor = decay_factor

    def compute_static_inflation(self, static_costmap):
        lethal_mask = (static_costmap >= COST_LETHAL)
        distance_field = distance_transform_edt(~lethal_mask)

        inflated_costs = np.zeros((self.height, self.width), dtype=np.uint8)
        
        inscribed_mask = (distance_field <= self.inscribed_radius) & ~lethal_mask
        inflated_costs[inscribed_mask] = COST_INSCRIBED

        buffer_mask = (distance_field > self.inscribed_radius) & (distance_field <= self.inflation_radius)
        if np.any(buffer_mask):
            d = distance_field[buffer_mask] - self.inscribed_radius
            costs = COST_INSCRIBED * np.exp(-self.decay_factor * d)
            inflated_costs[buffer_mask] = np.clip(costs, 1, COST_INSCRIBED).astype(np.uint8)

        static_master = np.maximum(static_costmap, inflated_costs)
        return static_master, distance_field

class LayeredCostmap:
    def __init__(self, grid_map, local_window_size=28):
        self.height, self.width = grid_map.shape
        self.local_window_size = local_window_size
        
        self.static_layer = StaticLayer(grid_map)
        self.obstacle_layer = ObstacleLayer(self.height, self.width, obstacle_radius=1.1)
        self.inflation_layer = InflationLayer(self.height, self.width, inscribed_radius=0.65, inflation_radius=2.5)
        
        self.base_costmap, self.static_dist = self.inflation_layer.compute_static_inflation(self.static_layer.costmap)
        self.master_costmap = self.base_costmap.copy()
        self.distance_map = self.static_dist.copy()

    def update(self, robot_pos, dynamic_obstacles=None, lidar_hits=None):
        self.master_costmap = self.base_costmap.copy()
        
        if dynamic_obstacles is not None:
            for obs in dynamic_obstacles:
                self.obstacle_layer.stamp_obstacle(self.master_costmap, obs[:2], inflation_radius=2.0)
                
        if lidar_hits is not None:
            for hit in lidar_hits:
                self.obstacle_layer.stamp_obstacle(self.master_costmap, hit, inflation_radius=1.0, decay_factor=1.5)
            
        return self.master_costmap, self.distance_map

    def get_local_window_bounds(self, robot_pos):
        rx, ry = int(robot_pos[0]), int(robot_pos[1])
        w_half = self.local_window_size
        min_x = max(0, rx - w_half)
        max_x = min(self.width, rx + w_half)
        min_y = max(0, ry - w_half)
        max_y = min(self.height, ry + w_half)
        return min_x, max_x, min_y, max_y


# ==============================================================================
# RASTGELE HARİTA SEÇİCİ
# ==============================================================================

def load_random_moving_ai_map():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    map_files = [f for f in os.listdir(script_dir) if f.endswith('.map')]
    
    if not map_files:
        raise FileNotFoundError(f"'{script_dir}' klasöründe hiç .map uzantılı dosya bulunamadı!")
    
    chosen_map = np.random.choice(map_files)
    filepath = os.path.join(script_dir, chosen_map)
    print(f"Rastgele Seçilen Harita Dosyası: {chosen_map}")

    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        lines = [line.strip() for line in f.readlines()]
        
    height = int([l for l in lines if l.startswith('height')][0].split()[1])
    width = int([l for l in lines if l.startswith('width')][0].split()[1])
    
    map_start = lines.index('map') + 1
    raw_str = "".join(lines[map_start:map_start + height])
    
    ascii_grid = np.frombuffer(raw_str.encode('ascii'), dtype=np.uint8).reshape((height, width))
    obstacle_chars = np.array([ord('@'), ord('T'), ord('O')], dtype=np.uint8)
    return np.isin(ascii_grid, obstacle_chars).astype(np.uint8), chosen_map

def snap_to_free_cell(distance_map, point, min_clearance=1.5):
    x, y = int(point[0]), int(point[1])
    if 0 <= y < distance_map.shape[0] and 0 <= x < distance_map.shape[1]:
        if distance_map[y, x] >= min_clearance:
            return np.array([float(x), float(y)])
            
    free_y, free_x = np.nonzero(distance_map >= min_clearance)
    dists = np.hypot(free_x - x, free_y - y)
    nearest_idx = np.argmin(dists)
    return np.array([float(free_x[nearest_idx]), float(free_y[nearest_idx])])

def plan_global_path_astar(costmap, distance_map, start, goal):
    h, w = costmap.shape
    sx, sy = int(start[0]), int(start[1])
    gx, gy = int(goal[0]), int(goal[1])
    
    motions = (
        (1, 0, 1.0), (0, 1, 1.0), (-1, 0, 1.0), (0, -1, 1.0),
        (1, 1, 1.414), (1, -1, 1.414), (-1, 1, 1.414), (-1, -1, 1.414)
    )
    
    g_score = np.full((h, w), np.inf, dtype=np.float32)
    parent_x = np.full((h, w), -1, dtype=np.int32)
    parent_y = np.full((h, w), -1, dtype=np.int32)
    closed = np.zeros((h, w), dtype=bool)
    
    g_score[sy, sx] = 0.0
    open_set = [(0.0, sx, sy)]
    
    while open_set:
        _, cx, cy = heapq.heappop(open_set)
        
        if closed[cy, cx]:
            continue
        closed[cy, cx] = True
        
        if cx == gx and cy == gy:
            path = []
            while cx != -1 and cy != -1:
                path.append((cx, cy))
                px, py = parent_x[cy, cx], parent_y[cy, cx]
                cx, cy = px, py
            path.reverse()
            return np.array(path, dtype=np.float32)
            
        for dx, dy, move_cost in motions:
            nx, ny = cx + dx, cy + dy
            if 0 <= nx < w and 0 <= ny < h and not closed[ny, nx]:
                cell_cost = costmap[ny, nx]
                if cell_cost < COST_INSCRIBED:
                    if dx != 0 and dy != 0:
                        if costmap[cy, nx] >= COST_INSCRIBED or costmap[ny, cx] >= COST_INSCRIBED:
                            continue
                    
                    inflation_penalty = (cell_cost / 30.0)
                    tentative_g = g_score[cy, cx] + move_cost + inflation_penalty
                    
                    if tentative_g < g_score[ny, nx]:
                        g_score[ny, nx] = tentative_g
                        parent_x[ny, nx] = cx
                        parent_y[ny, nx] = cy
                        f_score = tentative_g + np.hypot(gx - nx, gy - ny)
                        heapq.heappush(open_set, (f_score, nx, ny))
                        
    return None

def get_local_goal(global_path, robot_pos, costmap=None, lookahead=12):
    dists = np.hypot(global_path[:, 0] - robot_pos[0], global_path[:, 1] - robot_pos[1])
    closest_idx = int(np.argmin(dists))
    end_idx = min(closest_idx + lookahead, len(global_path) - 1)
    if costmap is None or end_idx <= closest_idx:
        return global_path[end_idx]
        
    targets = global_path[closest_idx + 1 : end_idx + 1]
    dists_t = np.hypot(targets[:, 0] - robot_pos[0], targets[:, 1] - robot_pos[1])
    max_d = np.max(dists_t)
    n_samples = max(2, int(max_d * 2) + 1)
    alphas = np.linspace(0, 1, n_samples)
    xs = robot_pos[0] + np.outer(targets[:, 0] - robot_pos[0], alphas)
    ys = robot_pos[1] + np.outer(targets[:, 1] - robot_pos[1], alphas)
    ixs = np.clip(np.round(xs).astype(np.int32), 0, costmap.shape[1] - 1)
    iys = np.clip(np.round(ys).astype(np.int32), 0, costmap.shape[0] - 1)
    
    has_los = ~np.any(costmap[iys, ixs] >= COST_INSCRIBED, axis=1)
    
    if not has_los[0]:
        target_idx = closest_idx + 1
    else:
        false_indices = np.where(~has_los)[0]
        if len(false_indices) == 0:
            target_idx = end_idx
        else:
            first_false = false_indices[0]
            target_idx = closest_idx + 1 + (first_false - 1)
    return global_path[target_idx]

# ==============================================================================
# 200 IŞINLI ULTRA GENİŞ VE HIZLI LIDAR TARAMASI
# ==============================================================================

def simulate_lidar(robot_pos, robot_yaw, grid_map, hidden_static_obstacles, dynamic_obstacles, max_range=16.0, num_rays=200):
    h, w = grid_map.shape
    angles = np.linspace(-np.pi, np.pi, num_rays, endpoint=False) + robot_yaw
    hit_points = []
    
    step_size = 0.4
    steps = int(max_range / step_size)
    dists = np.arange(1, steps + 1) * step_size
    
    so_arr = np.array(hidden_static_obstacles) if hidden_static_obstacles else None
    obs_arr = np.array([obs[:2] for obs in dynamic_obstacles]) if dynamic_obstacles else None

    for angle in angles:
        cx = robot_pos[0] + dists * np.cos(angle)
        cy = robot_pos[1] + dists * np.sin(angle)
        
        valid = (cx >= 0) & (cx < w) & (cy >= 0) & (cy < h)
        if not np.any(valid):
            continue
            
        cx_v = cx[valid].astype(np.int32)
        cy_v = cy[valid].astype(np.int32)
        
        wall_hits = grid_map[cy_v, cx_v] == 1
        
        hidden_hits = np.zeros(len(cx_v), dtype=bool)
        if so_arr is not None:
            d_so = np.hypot(cx_v[:, None] - so_arr[:, 0], cy_v[:, None] - so_arr[:, 1])
            hidden_hits = np.any(d_so <= 0.9, axis=1)
            
        dyn_hits = np.zeros(len(cx_v), dtype=bool)
        if obs_arr is not None:
            d_obs = np.hypot(cx_v[:, None] - obs_arr[:, 0], cy_v[:, None] - obs_arr[:, 1])
            dyn_hits = np.any(d_obs <= 1.0, axis=1)
            
        total_hits = wall_hits | hidden_hits | dyn_hits
        
        if np.any(total_hits):
            first_idx = np.argmax(total_hits)
            hit_points.append(np.array([cx_v[first_idx], cy_v[first_idx]], dtype=np.float32))
        else:
            last_valid = np.where(valid)[0][-1]
            hit_points.append(np.array([cx[last_valid], cy[last_valid]], dtype=np.float32))
            
    return hit_points

# ==============================================================================
# HIZLI DWA KONTROLCÜSÜ (Max Hız: 3.0 m/s)
# ==============================================================================

MAX_CRUISE_SPEED = 3.0
MIN_PASSAGE_SPEED = 1.2
MAX_ACCEL = 3.5
MAX_YAWRATE = np.deg2rad(90.0)
MAX_DYAWRATE = np.deg2rad(130.0)
DT = 0.2
PREDICT_TIME = 2.0
TIME_STEPS = np.arange(1, int(PREDICT_TIME / DT) + 1) * DT

def motion(x, u, dt):
    x[2] += u[1] * dt
    x[0] += u[0] * np.cos(x[2]) * dt
    x[1] += u[0] * np.sin(x[2]) * dt
    x[3] = u[0]
    x[4] = u[1]
    return x

def compute_adaptive_speed_limit(x, local_goal, distance_map, goal):
    cx = int(np.clip(np.round(x[0]), 0, distance_map.shape[1] - 1))
    cy = int(np.clip(np.round(x[1]), 0, distance_map.shape[0] - 1))
    clearance = distance_map[cy, cx]
    
    v_clearance = np.clip(MIN_PASSAGE_SPEED + (clearance - 0.8) * 1.5, MIN_PASSAGE_SPEED, MAX_CRUISE_SPEED)
    
    target_yaw = np.arctan2(local_goal[1] - x[1], local_goal[0] - x[0])
    yaw_diff = np.abs(np.arctan2(np.sin(target_yaw - x[2]), np.cos(target_yaw - x[2])))
    v_turn = MAX_CRUISE_SPEED / (1.0 + 1.2 * yaw_diff)
    
    dist_goal = np.hypot(goal[0] - x[0], goal[1] - x[1])
    v_goal = max(1.0, dist_goal * 0.6)
    
    return float(min(v_clearance, v_turn, v_goal))

def dwa_control_costmap(x, local_goal, master_costmap, distance_map, goal):
    v_target_limit = compute_adaptive_speed_limit(x, local_goal, distance_map, goal)

    v_min = max(0.0, x[3] - MAX_ACCEL * DT)
    v_max = min(v_target_limit, max(v_min, x[3] + MAX_ACCEL * DT))
    w_min = max(-MAX_YAWRATE, x[4] - MAX_DYAWRATE * DT)
    w_max = min(MAX_YAWRATE, x[4] + MAX_DYAWRATE * DT)
    
    v_samples = np.linspace(v_min, v_max, 12)
    w_samples = np.linspace(w_min, w_max, 25)
    v_grid, w_grid = np.meshgrid(v_samples, w_samples)
    v_cand = v_grid.ravel()
    w_cand = w_grid.ravel()
    
    traj_yaw = x[2] + np.outer(w_cand, TIME_STEPS)
    traj_x = x[0] + np.cumsum(v_cand[:, None] * np.cos(traj_yaw) * DT, axis=1)
    traj_y = x[1] + np.cumsum(v_cand[:, None] * np.sin(traj_yaw) * DT, axis=1)
    
    h, w = master_costmap.shape
    oob_mask = (traj_x < 0) | (traj_x >= w) | (traj_y < 0) | (traj_y >= h)
    
    px = np.clip(np.round(traj_x).astype(np.int32), 0, w - 1)
    py = np.clip(np.round(traj_y).astype(np.int32), 0, h - 1)
    
    traj_costs = master_costmap[py, px]
    collision_mask = np.any(oob_mask, axis=1) | np.any(traj_costs >= COST_INSCRIBED, axis=1)
    
    dx = local_goal[0] - traj_x[:, -1]
    dy = local_goal[1] - traj_y[:, -1]
    error_yaw = np.arctan2(dy, dx) - traj_yaw[:, -1]
    cost_angle = np.abs(np.arctan2(np.sin(error_yaw), np.cos(error_yaw)))
    
    cost_dist = np.hypot(dx, dy)
    dist_final = np.hypot(goal[0] - x[0], goal[1] - x[1])
    speed_weight = 3.5 if dist_final > 3.0 else 1.0
    cost_speed = (v_target_limit - v_cand) * speed_weight
    
    peak_cost = np.max(traj_costs, axis=1).astype(np.float32)
    cost_map_penalty = (peak_cost / 254.0) * 1.0
    stop_penalty = np.where(v_cand < 0.2, 8.0, 0.0)
    
    total_cost = 1.0 * cost_angle + 1.2 * cost_dist + cost_speed + cost_map_penalty + stop_penalty
    total_cost[collision_mask] = np.inf
    
    if np.all(np.isinf(total_cost)):
        target_yaw = np.arctan2(local_goal[1] - x[1], local_goal[0] - x[0])
        yaw_diff = np.arctan2(np.sin(target_yaw - x[2]), np.cos(target_yaw - x[2]))
        recovery_w = np.clip(yaw_diff, -MAX_YAWRATE, MAX_YAWRATE)
        return [0.5, recovery_w], np.column_stack(([x[0]], [x[1]]))
        
    best_idx = int(np.argmin(total_cost))
    best_traj = np.column_stack((traj_x[best_idx], traj_y[best_idx]))
    return [v_cand[best_idx], w_cand[best_idx]], best_traj


# ==============================================================================
# CANLI VE HIZLI SİMÜLASYON DÖNGÜSÜ
# ==============================================================================

def run_simulation():
    grid_map, map_name = load_random_moving_ai_map()
    h, w = grid_map.shape

    NUM_STATIC_OBSTACLES = np.random.randint(3, 5)   # 3 veya 4 adet sabit engel
    NUM_DYNAMIC_OBSTACLES = np.random.randint(2, 4)  # 2 veya 3 adet hareketli engel

    temp_dist = distance_transform_edt(grid_map == 0)
    free_y, free_x = np.nonzero(temp_dist >= 2.0)
    
    hidden_static_obstacles = []
    if len(free_y) > 0:
        valid_indices = [idx for idx in range(len(free_y)) if (free_x[idx] > w * 0.1 or free_y[idx] > h * 0.1) and (free_x[idx] < w * 0.9 or free_y[idx] < h * 0.9)]
        if not valid_indices:
            valid_indices = list(range(len(free_y)))
            
        s_indices = np.random.choice(valid_indices, size=min(NUM_STATIC_OBSTACLES, len(valid_indices)), replace=False)
        for idx in s_indices:
            hidden_static_obstacles.append((float(free_x[idx]), float(free_y[idx])))

    print(f"Oluşturulan Gizli Sabit Engel Sayısı: {len(hidden_static_obstacles)}")

    layered_costmap = LayeredCostmap(grid_map, local_window_size=min(28, w // 2))
    master_costmap, distance_map = layered_costmap.update([2.0, 2.0])
    
    start_raw = np.array([2.0, 2.0])
    goal_raw = np.array([float(w - 3), float(h - 3)])
    
    start_xy = snap_to_free_cell(distance_map, start_raw)
    goal = snap_to_free_cell(distance_map, goal_raw)
    state = np.array([start_xy[0], start_xy[1], 0.0, 0.0, 0.0])

    print("A* Global Rota Planlanıyor...")
    global_path = plan_global_path_astar(master_costmap, distance_map, state[:2], goal)

    if global_path is None:
        print("HATA: Güvenli bir global rota bulunamadı!")
        return
    print(f"Global Rota Bulundu! Toplam Adım: {len(global_path)}")

    # Dinamik Engeller
    dynamic_obstacles = []
    if len(global_path) > 10:
        path_indices = np.linspace(5, len(global_path) - 6, NUM_DYNAMIC_OBSTACLES, dtype=int)
        for p_idx in path_indices:
            base_pt = global_path[p_idx]
            ox = np.clip(base_pt[0] + np.random.uniform(-2.0, 2.0), 2.0, float(w - 3))
            oy = np.clip(base_pt[1] + np.random.uniform(-2.0, 2.0), 2.0, float(h - 3))
            vx = np.random.uniform(-0.18, 0.18)
            vy = np.random.uniform(-0.18, 0.18)
            dynamic_obstacles.append(np.array([ox, oy, vx, vy]))
            
    if not dynamic_obstacles:
        mid_pt = global_path[len(global_path) // 2]
        dynamic_obstacles = [np.array([mid_pt[0] + 2.0, mid_pt[1] + 2.0, -0.12, -0.06])]

    trajectory_history = [state[:2].copy()]
    
    plt.ion()
    fig, ax = plt.subplots(figsize=(10.5, 9))
    fig.patch.set_facecolor('#0d1117')
    ax.set_facecolor('#0d1117')

    costmap_img = ax.imshow(
        master_costmap, 
        cmap='inferno', 
        origin='lower', 
        alpha=0.88, 
        vmin=0, 
        vmax=255
    )

    cbar = plt.colorbar(costmap_img, ax=ax, fraction=0.038, pad=0.025)
    cbar.set_ticks([0, 60, 160, 253, 254, 255])
    cbar.set_ticklabels([
        "0: Serbest Alan",
        "60: Tampon Bölge",
        "160: Yaklaşma Cezası",
        "253: Inscribed Sınır",
        "254: Lethal Engel",
        "255: Bilinmeyen"
    ])
    cbar.ax.tick_params(labelsize=8)
    cbar.set_label(f"Harita: {map_name} | Dinamik Rota Yeniden Planlama Aktif", rotation=270, labelpad=18, fontweight='bold')

    global_path_plot, = ax.plot(global_path[:, 0], global_path[:, 1], "--c", linewidth=2.0, alpha=0.9, label="A* Global Rota")
    ax.plot(goal[0], goal[1], "*g", markersize=14, label="Nihai Hedef")

    if hidden_static_obstacles:
        so_arr = np.array(hidden_static_obstacles)
        ax.plot(so_arr[:, 0], so_arr[:, 1], "+r", markersize=10, markeredgewidth=2.5, label="Sabit Engel")

    dyn_plots = []
    dyn_circles = []
    for i, obs in enumerate(dynamic_obstacles):
        p, = ax.plot([obs[0]], [obs[1]], "om", markersize=9, label="Dinamik Engel" if i == 0 else "")
        circ = plt.Circle((obs[0], obs[1]), 2.5, color='magenta', fill=False, linestyle='--', linewidth=1.2, alpha=0.7)
        ax.add_patch(circ)
        dyn_plots.append(p)
        dyn_circles.append(circ)

    rob_plot, = ax.plot([state[0]], [state[1]], "ob", markersize=8, label="Robot")
    path_plot, = ax.plot([state[0]], [state[1]], "-b", linewidth=2.2, label="Robot Yolu")
    pred_plot, = ax.plot([state[0]], [state[1]], "-g", linewidth=1.6, label="DWA Yörünge")
    local_goal_plot, = ax.plot([state[0]], [state[1]], "xy", markersize=10, markeredgewidth=2, label="Alt Hedef")
    
    lidar_scatter = ax.scatter([], [], c='yellow', s=12, alpha=0.6, zorder=5, label="LiDAR Tarama Noktaları")

    margin = 10
    ax.set_xlim([0, w])
    ax.set_ylim([0, h])
    ax.legend(loc="upper left", framealpha=0.9)
    ax.grid(True, alpha=0.15, color="gray")

    plt.show(block=False)
    plt.pause(0.1)

    print("\n--- Dinamik Rota Planlamalı Simülasyon Başlatıldı ---")

    for step in range(2500):
        for obs in dynamic_obstacles:
            next_x = obs[0] + obs[2] * DT
            next_y = obs[1] + obs[3] * DT
            ix = int(np.clip(np.round(next_x), 0, w - 1))
            iy = int(np.clip(np.round(next_y), 0, h - 1))
            
            if grid_map[iy, ix] == 0:
                obs[0] = next_x
                obs[1] = next_y
            else:
                obs[2] *= -1
                obs[3] *= -1

        # LiDAR Taraması
        lidar_hits = simulate_lidar(state[:2], state[2], grid_map, hidden_static_obstacles, dynamic_obstacles)

        # Maliyet haritasını güncelle
        master_costmap, distance_map = layered_costmap.update(state[:2], dynamic_obstacles, lidar_hits)

        # ======================================================================
        # DİNAMİK ROTA YENİDEN PLANLAMA (Her 25 adımda bir veya sıkışmada)
        # ======================================================================
        if step % 25 == 0:
            new_path = plan_global_path_astar(master_costmap, distance_map, state[:2], goal)
            if new_path is not None and len(new_path) > 2:
                global_path = new_path
                global_path_plot.set_data(global_path[:, 0], global_path[:, 1])

        dist_to_goal = np.hypot(state[0] - goal[0], state[1] - goal[1])
        if dist_to_goal <= 2.0:
            print(f"\nHedefe başarıyla ve çarpmadan ulaşıldı! (Adım: {step})")
            break

        if step % 100 == 0:
            print(f"Adım {step:4d} | Konum: ({state[0]:5.1f}, {state[1]:5.1f}) | Hız: {state[3]:.2f} m/s | Kalan: {dist_to_goal:5.1f}m", flush=True)
            
        dyn_lookahead = int(np.clip(7 + int(state[3] * 3.5), 7, 18))
        local_goal = get_local_goal(global_path, state[:2], master_costmap, lookahead=dyn_lookahead)
        
        u, best_traj = dwa_control_costmap(state, local_goal, master_costmap, distance_map, goal)
        state = motion(state, u, DT)
        trajectory_history.append(state[:2].copy())
        
        for i, obs in enumerate(dynamic_obstacles):
            dyn_plots[i].set_data([obs[0]], [obs[1]])
            dyn_circles[i].center = (obs[0], obs[1])
            
        rob_plot.set_data([state[0]], [state[1]])
        local_goal_plot.set_data([local_goal[0]], [local_goal[1]])
        pred_plot.set_data(best_traj[:, 0], best_traj[:, 1])
        
        hist = np.array(trajectory_history)
        path_plot.set_data(hist[:, 0], hist[:, 1])
        
        if lidar_hits:
            hits_arr = np.array(lidar_hits)
            lidar_scatter.set_offsets(hits_arr)
        else:
            lidar_scatter.set_offsets(np.empty((0, 2)))
            
        v_lim = compute_adaptive_speed_limit(state, local_goal, distance_map, goal)
        ax.set_title(f"Adım: {step} | Hız: {state[3]:.2f} m/s (Limit: {v_lim:.2f}) | LiDAR Nokta: {len(lidar_hits)} | Kalan: {dist_to_goal:.1f} m", color='white')
        
        fig.canvas.draw()
        fig.canvas.flush_events()

    plt.ioff()
    plt.show()

if __name__ == '__main__':
    run_simulation()