from ultralytics import YOLO

# 1. Modeli yükle
model = YOLO("best.pt")

# 2. İndirdiğin verisetinden seçip yan klasöre attığın görselin adı
gorsel_yolu = "test_yaya.jpg"

# 3. Tahmini çalıştır (save=True ile işaretlenmiş resmi kaydeder)
results = model.predict(source=gorsel_yolu, conf=0.5, save=True)

# 4. Tespit edilen engeli ve güven oranını yazdır
for result in results:
    for box in result.boxes:
        cls_id = int(box.cls[0])
        conf = float(box.conf[0])
        name = model.names[cls_id]
        
        print(f"Engel Türü: {name} | Güven Oranı: %{conf * 100:.2f}")
