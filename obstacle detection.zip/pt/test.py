import cv2
from ultralytics import YOLO

model = YOLO('best.pt')
cap = cv2.VideoCapture(0)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # Model ile anlık tespit
    results = model(frame, conf=0.5)
    annotated_frame = results[0].plot()

    # Görüntüyü ekrana yansıtma
    cv2.imshow("Windows 11 - Engel Tespiti", annotated_frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
